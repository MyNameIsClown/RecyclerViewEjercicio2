package com.carrasco.openmapsapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.carrasco.openmapsapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val locations = (1..100).map {
        Place("Lugar $it", "https://loremflickr.com/g/320/240/paris?lock=$it")
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.adapter = MapAdapter(locations)
    }
}