package com.carrasco.openmapsapp

data class Place (val name: String, val image: String)